# Pneumonia Detection from Chest X-Ray using Deep Learning on AWS

This repo contains the reconstructed source code for the project *"Pneumonia
Detection from Chest X-Ray using Deep Learning on AWS"* (CNN built with
TensorFlow/Keras, trained on data stored in Amazon S3 via Amazon SageMaker).

> **Note:** The original notebook/source files were lost before upload. This
> version was reconstructed from the code embedded in the project report
> (`Pneumonia_Detection_using_CNN.docx`), which included the full notebook
> cells as screenshots and text. All logic, parameters, and comments match
> the original as documented in the report. If you have any other local
> backups (old zip exports, email attachments, chat uploads, IDE local
> history / `.ipynb_checkpoints`, SageMaker's "Git" tab, or a `git log` in
> a stray folder), it's worth double-checking those too — reconstruction
> from a report can miss cells that never made it into the writeup.

## Contents

- `Pneumonia_Detection_CNN.ipynb` — the notebook, reconstructed cell-by-cell.
- `pneumonia_detection.py` — the same code as a flat script.
- `requirements.txt` — Python dependencies.

## Pipeline

1. Download `chest_xray.zip` dataset from S3 (`pneumonia-project/raw-data/`).
2. Extract to `data/chest_xray/` (`train`, `val`, `test` folders, classes: `NORMAL`, `PNEUMONIA`).
3. Build `ImageDataGenerator`s with augmentation (rotation, zoom, horizontal flip) for training; rescale-only for validation/test.
4. Train a CNN (3x Conv2D+MaxPooling blocks -> Flatten -> Dense(128) -> Dropout(0.5) -> Dense(1, sigmoid)), Adam optimizer, binary cross-entropy.
5. Evaluate on validation and test sets.
6. Save the model (`final_pneumonia_model.h5`) and upload it back to S3 (`pneumonia-project/models/`).
7. Run real-time predictions on new chest X-ray images, with an image + prediction visualization helper.

## Usage

```bash
pip install -r requirements.txt
jupyter notebook Pneumonia_Detection_CNN.ipynb
# or
python pneumonia_detection.py
```

You'll need AWS credentials configured (`aws configure` or environment
variables) with access to the `pneumonia-project` S3 bucket referenced in
the code, and the dataset uploaded to `raw-data/chest_xray.zip` in that
bucket.
